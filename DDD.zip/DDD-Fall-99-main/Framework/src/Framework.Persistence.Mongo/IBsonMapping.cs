﻿namespace Framework.Persistence.Mongo
{
    public interface IBsonMapping
    {
        void Register();
    }
}