﻿namespace Framework.OutboxProcessor.EventBus.MassTransit
{
    public class MassTransitConfig
    {
        public string RabbitMqConnectionString { get; set; }
    }
}