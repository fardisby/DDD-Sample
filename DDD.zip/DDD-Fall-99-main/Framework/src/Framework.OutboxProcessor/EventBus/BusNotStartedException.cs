﻿using System;

namespace Framework.OutboxProcessor.EventBus
{
    public class BusNotStartedException : Exception
    {
        
    }
}