﻿using System;

namespace Framework.OutboxProcessor.DataStore
{
    public class NoChangeTrackerException : Exception
    {
        
    }
}