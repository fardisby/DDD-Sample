﻿namespace Framework.Domain
{
    public interface IRepository
    {
        
    }
}