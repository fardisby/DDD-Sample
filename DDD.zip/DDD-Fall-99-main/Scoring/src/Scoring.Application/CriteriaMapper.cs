﻿using Framework.Core.Specifications;
using Scoring.Application.Contracts.Rules;
using Scoring.Domain.Model.Applicants;
using Scoring.Domain.Model.Rules;

namespace Scoring.Application
{
    public class CriteriaMapper
    {
        public static Specification<Applicant> Map(CriteriaData commandCriteria)
        {
            throw new System.NotImplementedException();
        }
    }
}