﻿namespace Scoring.Config.Configuration
{
    public class PersistenceConfiguration
    {
        public string MongoConnectionString { get; set; }
        public string MongoDbName { get; set; }
    }
}