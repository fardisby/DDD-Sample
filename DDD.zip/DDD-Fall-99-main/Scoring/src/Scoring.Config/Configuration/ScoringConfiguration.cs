﻿namespace Scoring.Config.Configuration
{
    public class ScoringConfiguration
    {
        public PersistenceConfiguration Persistence { get; set; }
        public BusConfiguration Bus { get; set; }
    }
}