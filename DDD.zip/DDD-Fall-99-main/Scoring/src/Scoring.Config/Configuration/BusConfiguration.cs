﻿namespace Scoring.Config.Configuration
{
    public class BusConfiguration
    {
        public string RabbitMqConnection { get; set; }
    }
}