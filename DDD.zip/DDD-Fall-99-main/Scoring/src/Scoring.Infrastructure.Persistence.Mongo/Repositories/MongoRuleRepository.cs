﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Framework.Persistence.Mongo;
using MongoDB.Driver;
using Scoring.Domain.Model.Rules;

namespace Scoring.Infrastructure.Persistence.Mongo.Repositories
{
    public class MongoRuleRepository : MongoRepository<Rule, Guid>, IRuleRepository
    {
        public MongoRuleRepository(IMongoDatabase database) : base(database) { }

        public Task Add(Rule rule)
        {
            return AggregateCollection.InsertOneAsync(rule);
        }

        public Task<Rule> Get(Guid id)
        {
            return AggregateCollection.Find(a => a.Id == id).FirstOrDefaultAsync();
        }

        public Task<List<Rule>> GetActiveRules()
        {
            return AggregateCollection.Find(a => a.IsActive).ToListAsync();
        }
    }
}
