﻿using System;

namespace LoanApplications.Domain.Model.InterestRatePolicies.Exceptions
{
    public class ConflictRuleException : Exception
    {
        
    }
}