﻿using System;

namespace LoanApplications.Application.Contracts
{
    public class PlaceLoanApplication
    {
        public long ApplicantId { get; set; }
        public long Amount { get; set; }
    }
}
